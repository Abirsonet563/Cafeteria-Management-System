package com.mycompany.apu_Cafeteria;

import apu_Cafeteria.Forms.Progress;

public class Apu_Cafeteria {

    public static void main(String[] args) {
        
        // Main controller here
        
        boolean progressed = false;
        if(!progressed) {
            Progress p = new Progress();
            p.setVisible(true);

        }
    }
}
